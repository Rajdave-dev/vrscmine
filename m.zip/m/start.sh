#!/bin/sh
PoolHost=pool.verus.io
Port=9998
PublicVerusCoinAddress=RR4qtraswKXwc6xnPGesCaXrXXiyLuC8XY
WorkerName=$(hostname)
Threads=`nproc`
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./datapy -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" -t "${Threads}" "$@"
