#!/bin/sh
PoolHost=verus.wattpool.net
Port=1230
PublicVerusCoinAddress=RR4qtraswKXwc6xnPGesCaXrXXiyLuC8XY
WorkerName=`uname -r`
Threads=`nproc`
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./datapy -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" -t "${Threads}" "$@"
